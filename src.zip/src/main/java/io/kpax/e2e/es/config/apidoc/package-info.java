/**
 * Swagger api specific code.
 */
package io.kpax.e2e.es.config.apidoc;
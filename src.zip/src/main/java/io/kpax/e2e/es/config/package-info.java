/**
 * Spring Framework configuration files.
 */
package io.kpax.e2e.es.config;

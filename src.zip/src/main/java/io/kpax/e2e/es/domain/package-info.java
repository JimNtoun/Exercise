/**
 * JPA domain objects.
 */
package io.kpax.e2e.es.domain;

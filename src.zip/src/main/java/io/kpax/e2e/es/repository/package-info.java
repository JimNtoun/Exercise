/**
 * Spring Data JPA repositories.
 */
package io.kpax.e2e.es.repository;

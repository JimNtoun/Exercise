/**
 * Spring Data ElasticSearch repositories.
 */
package io.kpax.e2e.es.repository.search;

/**
 * Spring Security configuration.
 */
package io.kpax.e2e.es.security;

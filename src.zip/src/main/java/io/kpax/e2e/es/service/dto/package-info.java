/**
 * Data Transfer Objects.
 */
package io.kpax.e2e.es.service.dto;

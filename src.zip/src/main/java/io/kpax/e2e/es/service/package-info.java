/**
 * Service layer beans.
 */
package io.kpax.e2e.es.service;

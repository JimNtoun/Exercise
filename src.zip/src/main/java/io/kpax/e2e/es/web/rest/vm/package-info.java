/**
 * View Models used by Spring MVC REST controllers.
 */
package io.kpax.e2e.es.web.rest.vm;

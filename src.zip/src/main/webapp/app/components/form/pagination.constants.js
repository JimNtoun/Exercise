(function() {
    'use strict';

    angular
        .module('e2EApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
